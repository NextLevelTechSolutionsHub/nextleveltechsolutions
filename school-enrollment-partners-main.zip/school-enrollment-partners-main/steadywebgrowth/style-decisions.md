# Steady Web Growth Style Decisions

## No eyebrow text bubbles

Do not use pill-shaped eyebrow labels or badge-like text bubbles above headings. They make the design feel too AI-generated and overly templated.

Use simple section kickers instead:

- Small uppercase text.
- Teal on light backgrounds.
- Soft white text on dark backgrounds.
- No pill border.
- No rounded capsule background.
- No dot icon.

Example CSS direction:

```css
.kicker {
  display: block;
  color: #00A889;
  font-size: 0.78rem;
  font-weight: 850;
  letter-spacing: 0.14em;
  text-transform: uppercase;
  margin-bottom: 16px;
}
```

This keeps the site cleaner, more premium, and less obviously template-like.
