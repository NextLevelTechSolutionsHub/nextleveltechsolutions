# Steady Web Growth Website Design Document

## Purpose

This document defines the visual direction, layout system, website structure, content style, and implementation rules for steadywebgrowth.com.

The goal is to create a clean, trustworthy, practical website for general small business referrals. The site should feel professional and growth-oriented without looking flashy, technical, or overly niche.

## Brand feel

Steady Web Growth should feel:

- Clear.
- Calm.
- Trustworthy.
- Practical.
- Professional.
- Growth-oriented.
- Friendly to small business owners.
- Simple enough to understand quickly.

The site should communicate that the business helps owners improve their online presence in a steady, reliable way. It should not feel like a hype-heavy marketing agency or a cheap template shop.

## Logo direction

The current logo direction uses:

- A dark navy wordmark.
- A teal accent on the word “Web.”
- A simple growth icon with ascending bars and a curved upward arrow.
- A clean white background.

### Logo usage

Use the full wordmark in the header and footer where space allows.

Use the icon-only mark for:

- Favicon.
- Social profile image.
- Mobile app-style icon.
- Small avatar placements.
- Browser tab and compact UI use.

### Logo personality

The logo should feel like steady upward progress. Avoid icons that feel too aggressive, financial-only, startup-like, or abstract beyond recognition.

## Color system

The color palette should be based on the logo: deep navy, teal, soft blue-gray, and clean white space.

### Primary colors

**Deep Navy**  
Hex: `#062B4F`  
Use for headings, body contrast, primary buttons, footer backgrounds, and key brand elements.

**Growth Teal**  
Hex: `#00A889`  
Use for accents, icons, links, highlights, secondary buttons, badges, and small visual emphasis.

**Dark Blue**  
Hex: `#0B3D6E`  
Use as a secondary navy for gradients, cards, and hover states.

### Supporting colors

**Soft Sky**  
Hex: `#EAF6F5`  
Use for subtle background sections and callout cards.

**Pale Blue Gray**  
Hex: `#F3F7FA`  
Use for page section backgrounds, form areas, and card contrast.

**Slate Text**  
Hex: `#405466`  
Use for body copy and secondary content.

**Light Border**  
Hex: `#DDE8EE`  
Use for card borders, form fields, and divider lines.

**White**  
Hex: `#FFFFFF`  
Use as the main page background.

### Accent use rules

- Navy should carry most of the brand weight.
- Teal should be used sparingly to signal progress, action, and highlights.
- White space should dominate the layout.
- Avoid bright green, neon blue, red, orange-heavy gradients, or playful color palettes.

## Typography

The typography should be modern, clean, and easy to read.

### Recommended web fonts

**Primary headline font:** Inter, Manrope, or Plus Jakarta Sans  
**Body font:** Inter, Lato, or Arial  
**Fallback:** system sans-serif

### Font direction

Use a clean sans-serif system. Avoid ornate serif fonts, childish rounded fonts, condensed fonts, or overly futuristic tech fonts.

### Type scale

Desktop:

- H1: 56px to 68px, line-height 1.05 to 1.1.
- H2: 38px to 46px, line-height 1.15.
- H3: 24px to 30px, line-height 1.2.
- Body: 17px to 18px, line-height 1.65.
- Small text: 14px to 15px.

Mobile:

- H1: 38px to 44px.
- H2: 30px to 36px.
- H3: 22px to 26px.
- Body: 16px to 17px.

### Text style rules

- Headlines should be short and outcome-focused.
- Body copy should be plainspoken and direct.
- Avoid long dense paragraphs.
- Use short explanatory sections and cards.
- Use bold only for important emphasis.

## Layout system

### Page width

- Max content width: 1180px to 1240px.
- Text-heavy sections: 760px to 860px.
- Hero content: 600px to 720px if paired with a visual.

### Spacing

- Section padding desktop: 88px to 120px top and bottom.
- Section padding mobile: 56px to 76px top and bottom.
- Card gap: 24px to 32px.
- Inner card padding: 28px to 36px.

### Border radius

Use soft, modern rounding:

- Buttons: 999px or 12px depending on style.
- Cards: 18px to 24px.
- Form fields: 12px to 14px.
- Image corners: 20px to 28px.

### Shadows

Use subtle shadows only.

Recommended:

```css
box-shadow: 0 18px 45px rgba(6, 43, 79, 0.08);
```

Avoid heavy drop shadows, glossy effects, or unrealistic mockup shadows.

## Visual style

The site should use a clean business-service visual language.

### Recommended visuals

- Abstract growth graphics.
- Website interface cards.
- Simple dashboards.
- Local business imagery.
- Owner/operator scenes.
- Clean service icons.
- Before/after style website preview cards.
- Process diagrams.

### Avoid

- Cartoon illustrations.
- Stock photos that feel fake or corporate cliché.
- Overly futuristic AI graphics.
- Loud marketing agency visuals.
- Random city skyline imagery unless location-specific.
- Dense technical diagrams.

## Header design

The header should be simple and conversion-focused.

### Header elements

- Logo on left.
- Navigation on right.
- Primary CTA button.

### Suggested navigation

- Services
- Website Review
- Work
- About
- Contact

### Header CTA

Use:

> Request a Website Review

### Header behavior

- Sticky header is optional.
- If sticky, keep it compact and clean.
- Mobile navigation should collapse into a simple menu.
- CTA should remain visible on desktop.

## Button system

### Primary button

Use navy background with white text.

Example:

```css
background: #062B4F;
color: #FFFFFF;
border-radius: 999px;
```

Hover:

```css
background: #0B3D6E;
transform: translateY(-1px);
```

### Secondary button

Use white background, navy text, and light border.

Example:

```css
background: #FFFFFF;
color: #062B4F;
border: 1px solid #DDE8EE;
```

### Accent button

Use teal background when the design needs a stronger action cue.

Example:

```css
background: #00A889;
color: #FFFFFF;
```

Use accent buttons sparingly so they do not overpower the brand.

## Card system

Cards should be clean, spacious, and practical.

### Service cards

Each service card should include:

- Small icon.
- Outcome-focused title.
- Short explanation.
- Optional link.

Example titles:

- Clearer Websites
- Local Search Foundations
- Better Lead Capture
- Ongoing Improvements

### Outcome cards

Use three main outcome cards on the homepage:

1. **A clearer first impression**
2. **A stronger local presence**
3. **More ways for customers to contact you**

### Card style

```css
background: #FFFFFF;
border: 1px solid #DDE8EE;
border-radius: 22px;
box-shadow: 0 18px 45px rgba(6, 43, 79, 0.06);
padding: 32px;
```

## Icon system

Icons should be simple line or filled icons using navy and teal.

### Icon themes

- Growth arrow.
- Website window.
- Search pin.
- Phone/call.
- Form/message.
- Checkmark.
- Compass/path.
- Bar chart.

### Icon rules

- Keep icons consistent in stroke weight.
- Use teal for small accents.
- Avoid overly detailed icons.
- Avoid icons that look financial-only unless paired with website context.

## Homepage structure

### 1. Hero section

Goal: Immediately explain who the brand helps and what outcome it creates.

Recommended headline:

> Websites and Local Marketing for Growing Small Businesses

Recommended subheadline:

> Steady Web Growth helps small businesses build clear, trustworthy websites and practical local marketing systems that make it easier for customers to find you, trust you, and contact you.

Primary CTA:

> Request a Website Review

Secondary CTA:

> See How We Help

Visual direction:

- Website preview card.
- Growth chart accent.
- Small trust badges.
- Clean browser-window mockup.
- Simple metric cards such as “Calls,” “Inquiries,” and “Local Visibility.”

Do not lead with company history.

### 2. Problem section

Explain the cost of a weak website in plain language.

Possible heading:

> Your website should support the referral, not slow it down.

Key points:

- People look you up before they call.
- An outdated website can create doubt.
- Confusing service pages cost inquiries.
- Mobile friction loses customers.
- A better website makes the next step obvious.

### 3. Outcomes section

Use three cards.

Recommended heading:

> Built for trust, clarity, and steady growth.

Cards:

- **Clearer first impression**: Make it obvious what you do, who you serve, and why someone should contact you.
- **Better local presence**: Strengthen the basics that help customers find and trust you online.
- **More inquiry paths**: Make calls, quote requests, bookings, and contact forms easier to complete.

### 4. Services section

Recommended heading:

> Practical website and local growth services.

Service groups:

- Small Business Websites
- Website Redesigns
- Local SEO Foundations
- Lead Capture and Conversion
- Website Care and Improvements

### 5. Process section

Recommended heading:

> A simple process that keeps the work focused.

Steps:

1. **Review**: Look at the current website, local presence, and inquiry path.
2. **Plan**: Identify the highest-impact improvements.
3. **Build**: Create or improve the site, pages, forms, and calls to action.
4. **Improve**: Track what matters and continue making useful updates.

### 6. Work/portfolio preview

Use project cards when available.

If portfolio details are limited, use category examples instead:

- Local service website redesign.
- Contact flow improvement.
- Landing page build.
- Google profile and website alignment.

Avoid fake case studies or fabricated results.

### 7. Trust section

Recommended heading:

> Straightforward help for business owners who do not want marketing noise.

Key proof points:

- Practical recommendations.
- Clear communication.
- Mobile-first builds.
- Conversion-focused pages.
- Ongoing support options.

### 8. Final CTA

Recommended heading:

> Want a clearer website and a stronger path to new customers?

CTA:

> Request a Website Review

## Services page structure

The Services page should explain the practical service menu without becoming too broad.

### Recommended sections

1. Hero: “Website and Local Growth Services for Small Businesses.”
2. Service overview grid.
3. Individual service detail sections.
4. Who this is for.
5. Process.
6. FAQ.
7. Final CTA.

### Service detail copy direction

Every service should answer:

- What it is.
- Why it matters.
- What the client gets.
- What business outcome it supports.

## Website Review page structure

This should be the main conversion page for referrals.

### Purpose

Capture people who were referred and want to know what is wrong with their current website or online presence.

### Recommended headline

> Request a Practical Website Review

### Recommended subheadline

> We will look at your website, local presence, and inquiry path, then show you the first improvements that would make the biggest difference.

### Form fields

Keep the form short:

- Name.
- Business name.
- Website URL.
- Email.
- Phone.
- What do you want help with?

### Review focus areas

- First impression.
- Mobile experience.
- Service clarity.
- Calls to action.
- Trust signals.
- Local visibility basics.
- Inquiry friction.

## About page structure

The About page should build trust, not overexplain the company history.

### Recommended heading

> Practical web help for small businesses that want steady growth.

### Core message

Steady Web Growth exists to help business owners create websites that are easier to understand, easier to trust, and easier to act on.

Mention that it is operated by Next Level Tech Solutions LLC.

## Contact page structure

The Contact page should be simple.

### Recommended heading

> Let’s talk about your website.

Include:

- Short form.
- Email.
- Optional phone number.
- Expected response time.
- Simple note: “Not sure where to start? Request a website review.”

## Copywriting rules

### Good phrases

- Clearer website.
- Stronger first impression.
- More calls and inquiries.
- Practical local marketing.
- Steady growth.
- Easy for customers to find and contact you.
- Better path from referral to inquiry.
- Website improvements that support real business goals.

### Avoid phrases

- Explosive growth.
- 10x your business.
- Dominate your market.
- Guaranteed leads.
- Revolutionary AI marketing.
- Full-stack digital transformation.
- Best-in-class omnichannel solutions.

## SEO and AI visibility structure

Each page should use clear headings and answer common owner questions.

### Recommended schema

Use when possible:

- Organization schema.
- ProfessionalService schema.
- Service schema.
- FAQPage schema.
- Breadcrumb schema.

### FAQ examples

- How do I know if my small business website needs a redesign?
- What should a small business website include?
- Can you help with local SEO?
- Do you build websites for any type of business?
- What happens during a website review?
- Can you help improve an existing website instead of rebuilding it?

### Metadata rules

Page titles should combine service, audience, and brand.

Example:

> Small Business Website Design | Steady Web Growth

Meta descriptions should be practical and outcome-driven.

Example:

> Steady Web Growth builds clear, trustworthy websites and local marketing foundations for small businesses that want more calls, inquiries, and customers.

## Forms and conversion elements

### Global conversion rules

- Include a CTA above the fold.
- Include a CTA near the middle of long pages.
- Include a final CTA at the bottom.
- Make phone and form options easy on mobile.
- Use forms that are short and clear.
- Avoid forcing users into a calendar link too early unless they are ready.

### Form design

- Large fields.
- Clear labels.
- Minimal required fields.
- Strong submit button.
- Reassuring microcopy.

Example microcopy:

> Tell us where your website is today and what you want it to do better. We will review it and recommend the first practical improvements.

## Mobile design rules

The site should be designed mobile-first.

### Mobile priorities

- Header must be simple.
- Logo must be readable or use icon plus short name.
- CTA must be easy to tap.
- Text must not be cramped.
- Cards should stack cleanly.
- Forms should be easy to complete.
- Phone/contact actions should be obvious.

## Animation rules

Use subtle animation only.

### Recommended animations

- Fade-up section entrances.
- Gentle card stagger.
- Button hover lift.
- Subtle icon movement only if lightweight.

### Avoid

- Fast motion.
- Parallax-heavy effects.
- Animation that delays reading.
- Complicated scroll hijacking.
- Flashy agency-style motion.

Respect reduced-motion preferences in CSS.

Example:

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation: none !important;
    transition: none !important;
    scroll-behavior: auto !important;
  }
}
```

## Implementation rules

### If building in WordPress HTML blocks

- Scope CSS under `.swg-site`.
- Do not use global resets.
- Use lightweight JavaScript only for optional animation.
- Keep components reusable.
- Use placeholder image URLs that can be replaced later.
- Make all sections responsive.
- Avoid dependencies unless necessary.

### CSS naming

Use simple, scoped class names:

- `.swg-site`
- `.swg-container`
- `.swg-section`
- `.swg-hero`
- `.swg-card`
- `.swg-grid`
- `.swg-button`
- `.swg-button-primary`
- `.swg-button-secondary`
- `.swg-kicker`
- `.swg-final-cta`

### Accessibility

- Maintain good color contrast.
- Use real text, not text baked into images.
- Use descriptive button text.
- Use semantic headings.
- Add alt text to meaningful images.
- Ensure forms have labels.
- Make focus states visible.

## Example design tokens

```css
:root {
  --swg-navy: #062B4F;
  --swg-navy-2: #0B3D6E;
  --swg-teal: #00A889;
  --swg-soft-sky: #EAF6F5;
  --swg-bg: #F3F7FA;
  --swg-text: #405466;
  --swg-border: #DDE8EE;
  --swg-white: #FFFFFF;
  --swg-radius: 22px;
  --swg-shadow: 0 18px 45px rgba(6, 43, 79, 0.08);
}
```

## Design checklist before launch

- Full logo in header.
- Icon-only favicon.
- Clear hero headline.
- CTA above the fold.
- Mobile-first layout.
- Services explained by business outcome.
- Contact path is obvious.
- Forms are short and tested.
- No unsupported claims.
- Footer includes legal/operator language.
- Metadata added.
- Basic schema added where possible.
- Site speed is strong.
- Page works without animation.

## Final creative direction

The website should look like the brand name sounds: steady, clear, and growth-minded. It should give referred business owners confidence that they are in the right place, quickly explain how Steady Web Growth can help, and make the next step simple.