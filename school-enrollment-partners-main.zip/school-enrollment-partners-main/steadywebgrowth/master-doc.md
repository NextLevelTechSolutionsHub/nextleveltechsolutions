# Steady Web Growth Master Brand Document

## Brand overview

Steady Web Growth is the general referral-friendly web brand for small business website and local marketing projects that do not fit the more specialized niche brands.

The brand exists to solve a practical positioning problem: when someone refers a general business owner who needs a website, redesign, local SEO help, or basic digital marketing support, they need a clear and credible place to send that person. Steady Web Growth gives those referrals a home without diluting the specialized positioning of School Enrollment Partners or Next Level Tech Solutions.

## Domain

Primary domain: steadywebgrowth.com

## Business role in the brand architecture

Steady Web Growth should be treated as a focused generalist brand under the broader business structure.

### Brand structure

- **School Enrollment Partners**: Enrollment-focused marketing for Montessori schools, preschools, childcare centers, and early education programs.
- **Next Level Tech Solutions**: Websites, SEO, and growth systems for security integrators.
- **Steady Web Growth**: General small business websites, redesigns, local SEO, landing pages, and referral-based digital projects.

## Recommended legal/footer language

Use a simple footer line such as:

> Steady Web Growth is operated by Next Level Tech Solutions LLC.

If contracts, invoices, or formal proposals are used, the legal entity should remain Next Level Tech Solutions LLC unless a separate DBA is filed later.

## Core positioning

Steady Web Growth helps small businesses create clear, trustworthy websites and practical local marketing systems that generate more calls, inquiries, and customers over time.

### Positioning sentence

> We build clear websites and practical local marketing systems for small businesses that want steady, sustainable growth.

### Short version

> Websites and local marketing for growing small businesses.

### More direct version

> We help small businesses turn outdated websites into clear, trustworthy online systems that bring in more calls, inquiries, and customers.

## What the brand is

- A clean, practical website and local growth brand for small businesses.
- A referral-friendly destination for business owners who need digital help but do not fit a niche vertical.
- A trustworthy partner for owners who want clarity, better presentation, and more consistent inquiries.
- A low-hype, results-aware web brand.
- A flexible container for general projects, without becoming a generic agency that says yes to everything.

## What the brand is not

- Not the main niche brand for schools or security integrators.
- Not a flashy growth-hacking brand.
- Not a bargain-bin website shop.
- Not a design-only studio that ignores leads and conversions.
- Not an enterprise agency with unnecessary complexity.
- Not a replacement for the more specialized vertical brands.

## Audience

The primary audience is small business owners and operators who need a better website, clearer online presence, or local marketing support.

### Best-fit clients

- Local service businesses.
- Professional service providers.
- Trades and home service companies.
- Small businesses with outdated websites.
- Referral-based businesses that need a credible online presence.
- Owners who want calls, inquiries, quote requests, consultations, bookings, or form submissions.

### Lower-priority clients

- Large companies with internal marketing teams.
- Startups needing complex software development.
- Businesses that only want the cheapest possible website.
- Businesses with no clear offer, market, or ability to fulfill new leads.
- High-maintenance custom design clients with unclear goals.

## Core customer problems

- Their website looks outdated or untrustworthy.
- Their site does not clearly explain what they do.
- Their site does not make it easy to call, book, or request a quote.
- Their website does not work well on mobile.
- Their Google presence is weak or inconsistent.
- They rely on word of mouth but lose credibility when people look them up.
- They get referrals, but the website does not support the sale.
- They want steady growth without feeling overwhelmed by marketing jargon.

## Core outcomes

- A clearer, more professional website.
- Better trust with referred prospects.
- More calls and form submissions.
- A better mobile experience.
- Stronger local visibility.
- More consistent follow-up paths.
- A digital presence that feels stable, credible, and easy to understand.

## Primary offer direction

The initial offer should stay simple and broad enough for referrals.

### Main service categories

1. **Small Business Websites**
   - New websites.
   - Website redesigns.
   - Mobile-friendly pages.
   - Clear service pages.
   - Contact and quote request flows.

2. **Local Growth Foundations**
   - Google Business Profile improvements.
   - Local SEO basics.
   - Review presentation.
   - Service and location content.
   - Tracking setup.

3. **Lead Capture and Conversion**
   - Contact forms.
   - Booking links.
   - Quote request forms.
   - Click-to-call buttons.
   - Landing pages.
   - Follow-up automations when appropriate.

4. **Website Care and Improvements**
   - Ongoing updates.
   - Monthly improvements.
   - Content updates.
   - Basic reporting.
   - Site health checks.

## Recommended front-end CTA

The best general CTA is:

> Request a Website Review

Secondary CTA options:

- See How We Can Help
- Get a Website Plan
- Start a Conversation
- Request a Free Website Checkup

## Homepage messaging

### Hero headline options

- Websites and Local Marketing for Growing Small Businesses
- A Clearer Website. A Stronger Local Presence. Steadier Growth.
- Turn Your Website Into a Better First Impression
- Practical Websites That Help Small Businesses Grow

### Recommended hero headline

> Websites and Local Marketing for Growing Small Businesses

### Recommended hero subheadline

> Steady Web Growth helps small businesses build clear, trustworthy websites and practical local marketing systems that make it easier for customers to find you, trust you, and contact you.

### Recommended CTA

> Request a Website Review

## Brand voice

The voice should be clear, calm, practical, and trustworthy.

### Voice attributes

- Plainspoken.
- Helpful.
- Confident without hype.
- Results-aware.
- Friendly but professional.
- Simple enough for non-technical business owners.

### Avoid

- Overly technical language.
- Aggressive agency hype.
- False guarantees.
- Trendy startup language.
- Overpromising leads or revenue.
- Talking too much about design aesthetics before business outcomes.

## Messaging rules

- Benefits before features.
- Talk about the owner’s goals before talking about the company.
- Use plain words: calls, inquiries, quote requests, bookings, customers.
- Keep the concept of “steady growth” central.
- Emphasize trust, clarity, and consistency.
- Do not position Steady Web Growth as the specialist for schools or security integrators.
- Keep the brand flexible enough for referrals, but structured enough to avoid sounding generic.

## Suggested website pages

Start with a lean website.

1. **Home**
   - Brand positioning, outcomes, services, process, proof, CTA.

2. **Services**
   - Small business websites, website redesigns, local SEO foundations, lead capture, website care.

3. **Website Review**
   - Landing page for referral traffic and audit requests.

4. **Portfolio / Work**
   - Examples of websites or project types.

5. **About**
   - Simple trust-building page explaining the practical approach and connection to Next Level Tech Solutions LLC.

6. **Contact**
   - Form, email, phone if appropriate, and booking CTA.

## Suggested homepage sections

1. Hero: clear headline, subheadline, CTA, simple trust cue.
2. Problem section: outdated websites and unclear online presence cost trust.
3. Outcome cards: Clear Website, Better Local Presence, More Inquiries.
4. Services overview: Websites, Local SEO, Lead Capture, Website Care.
5. Process: Review, Plan, Build, Improve.
6. Proof or portfolio preview.
7. Why steady growth: practical improvements, no hype, clear priorities.
8. Final CTA: Request a Website Review.

## SEO direction

Steady Web Growth should avoid publishing broad generic marketing content at the start. The priority should be service and conversion pages.

### Initial SEO targets

- Small business website design.
- Website redesign for small businesses.
- Local business websites.
- Local SEO for small businesses.
- Website review for small businesses.
- Website care for small businesses.

### Content principles

- Write for business owners, not marketers.
- Use clear service language.
- Include FAQs.
- Explain process and expected outcomes.
- Support AI visibility with structured question-answer content.
- Avoid mass-produced generic blog posts.

## Project rules for future website work

- Use the design document as the visual source of truth.
- Keep layouts clean, spacious, and conversion-focused.
- Use the navy and teal growth palette from the logo.
- Use the full wordmark where space allows and the icon-only mark for small spaces.
- Every page needs a clear CTA.
- Every major service section should explain the business outcome first.
- Do not use childish, overly playful, or highly technical visual language.
- Keep the website easy for a small business owner to understand.

## One-line summary

Steady Web Growth is a clean, practical, referral-friendly web brand that helps small businesses build clearer websites, stronger local presence, and more consistent inquiry flow.