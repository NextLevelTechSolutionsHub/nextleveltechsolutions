$port = 5177
$root = $PSScriptRoot

Write-Host "Starting Preschool Owner Call Windows on http://127.0.0.1:$port/"
Write-Host "Press Ctrl+C to stop."

python -m http.server $port --directory $root
