const CALL_WINDOWS = [
  {
    label: "Morning admin reset",
    start: "09:15",
    end: "10:30",
    tier: "prime",
    why: "After drop-off settles and before lunch transitions start."
  },
  {
    label: "Nap / quiet-time desk block",
    start: "12:45",
    end: "14:15",
    tier: "prime",
    why: "Best bet for owner-directors because classrooms are usually in rest mode."
  },
  {
    label: "Pre-pickup admin gap",
    start: "15:05",
    end: "15:50",
    tier: "secondary",
    why: "Useful after wake-up and snack, before the pickup rush gets loud."
  },
  {
    label: "After-close owner catch-up",
    start: "17:35",
    end: "18:15",
    tier: "secondary",
    why: "Use for owners and directors, not front-desk routing."
  }
];

const STATES = [
  { abbr: "AK", name: "Alaska", x: 1, y: 7, zones: zone("Alaska", "America/Anchorage", "Aleutian", "America/Adak") },
  { abbr: "HI", name: "Hawaii", x: 2, y: 8, zones: zone("Hawaii", "Pacific/Honolulu") },
  { abbr: "WA", name: "Washington", x: 1, y: 2, zones: zone("Pacific", "America/Los_Angeles") },
  { abbr: "OR", name: "Oregon", x: 1, y: 3, zones: zone("Pacific", "America/Los_Angeles", "Mountain", "America/Denver") },
  { abbr: "CA", name: "California", x: 1, y: 4, zones: zone("Pacific", "America/Los_Angeles") },
  { abbr: "ID", name: "Idaho", x: 2, y: 3, zones: zone("Mountain", "America/Denver", "Pacific", "America/Los_Angeles") },
  { abbr: "NV", name: "Nevada", x: 2, y: 4, zones: zone("Pacific", "America/Los_Angeles", "Mountain", "America/Denver") },
  { abbr: "AZ", name: "Arizona", x: 2, y: 5, zones: zone("Arizona", "America/Phoenix", "Navajo Nation", "America/Denver") },
  { abbr: "MT", name: "Montana", x: 3, y: 2, zones: zone("Mountain", "America/Denver") },
  { abbr: "WY", name: "Wyoming", x: 3, y: 4, zones: zone("Mountain", "America/Denver") },
  { abbr: "UT", name: "Utah", x: 3, y: 5, zones: zone("Mountain", "America/Denver") },
  { abbr: "NM", name: "New Mexico", x: 3, y: 6, zones: zone("Mountain", "America/Denver") },
  { abbr: "ND", name: "North Dakota", x: 4, y: 2, zones: zone("Central", "America/Chicago", "Mountain", "America/Denver") },
  { abbr: "SD", name: "South Dakota", x: 4, y: 3, zones: zone("Central", "America/Chicago", "Mountain", "America/Denver") },
  { abbr: "NE", name: "Nebraska", x: 4, y: 4, zones: zone("Central", "America/Chicago", "Mountain", "America/Denver") },
  { abbr: "CO", name: "Colorado", x: 4, y: 5, zones: zone("Mountain", "America/Denver") },
  { abbr: "KS", name: "Kansas", x: 5, y: 5, zones: zone("Central", "America/Chicago", "Mountain", "America/Denver") },
  { abbr: "OK", name: "Oklahoma", x: 5, y: 6, zones: zone("Central", "America/Chicago") },
  { abbr: "TX", name: "Texas", x: 5, y: 7, zones: zone("Central", "America/Chicago", "Mountain", "America/Denver") },
  { abbr: "MN", name: "Minnesota", x: 5, y: 2, zones: zone("Central", "America/Chicago") },
  { abbr: "IA", name: "Iowa", x: 5, y: 3, zones: zone("Central", "America/Chicago") },
  { abbr: "MO", name: "Missouri", x: 6, y: 4, zones: zone("Central", "America/Chicago") },
  { abbr: "AR", name: "Arkansas", x: 6, y: 5, zones: zone("Central", "America/Chicago") },
  { abbr: "LA", name: "Louisiana", x: 6, y: 7, zones: zone("Central", "America/Chicago") },
  { abbr: "WI", name: "Wisconsin", x: 6, y: 2, zones: zone("Central", "America/Chicago") },
  { abbr: "IL", name: "Illinois", x: 6, y: 3, zones: zone("Central", "America/Chicago") },
  { abbr: "MS", name: "Mississippi", x: 7, y: 6, zones: zone("Central", "America/Chicago") },
  { abbr: "MI", name: "Michigan", x: 7, y: 2, zones: zone("Eastern", "America/Detroit", "Central", "America/Chicago") },
  { abbr: "IN", name: "Indiana", x: 7, y: 3, zones: zone("Eastern", "America/Indiana/Indianapolis", "Central", "America/Chicago") },
  { abbr: "KY", name: "Kentucky", x: 7, y: 4, zones: zone("Eastern", "America/New_York", "Central", "America/Chicago") },
  { abbr: "TN", name: "Tennessee", x: 7, y: 5, zones: zone("Central", "America/Chicago", "Eastern", "America/New_York") },
  { abbr: "AL", name: "Alabama", x: 8, y: 6, zones: zone("Central", "America/Chicago") },
  { abbr: "OH", name: "Ohio", x: 8, y: 3, zones: zone("Eastern", "America/New_York") },
  { abbr: "WV", name: "West Virginia", x: 8, y: 4, zones: zone("Eastern", "America/New_York") },
  { abbr: "NC", name: "North Carolina", x: 9, y: 5, zones: zone("Eastern", "America/New_York") },
  { abbr: "SC", name: "South Carolina", x: 9, y: 6, zones: zone("Eastern", "America/New_York") },
  { abbr: "GA", name: "Georgia", x: 9, y: 7, zones: zone("Eastern", "America/New_York") },
  { abbr: "FL", name: "Florida", x: 10, y: 8, zones: zone("Eastern", "America/New_York", "Central", "America/Chicago") },
  { abbr: "PA", name: "Pennsylvania", x: 9, y: 3, zones: zone("Eastern", "America/New_York") },
  { abbr: "VA", name: "Virginia", x: 9, y: 4, zones: zone("Eastern", "America/New_York") },
  { abbr: "NY", name: "New York", x: 10, y: 2, zones: zone("Eastern", "America/New_York") },
  { abbr: "MD", name: "Maryland", x: 10, y: 4, zones: zone("Eastern", "America/New_York") },
  { abbr: "DE", name: "Delaware", x: 11, y: 5, zones: zone("Eastern", "America/New_York") },
  { abbr: "NJ", name: "New Jersey", x: 11, y: 4, zones: zone("Eastern", "America/New_York") },
  { abbr: "CT", name: "Connecticut", x: 11, y: 3, zones: zone("Eastern", "America/New_York") },
  { abbr: "RI", name: "Rhode Island", x: 12, y: 4, zones: zone("Eastern", "America/New_York") },
  { abbr: "MA", name: "Massachusetts", x: 12, y: 3, zones: zone("Eastern", "America/New_York") },
  { abbr: "VT", name: "Vermont", x: 11, y: 2, zones: zone("Eastern", "America/New_York") },
  { abbr: "NH", name: "New Hampshire", x: 12, y: 2, zones: zone("Eastern", "America/New_York") },
  { abbr: "ME", name: "Maine", x: 13, y: 1, zones: zone("Eastern", "America/New_York") }
];

const dom = {
  userClock: document.querySelector("#userClock"),
  userDate: document.querySelector("#userDate"),
  callableCount: document.querySelector("#callableCount"),
  nextBest: document.querySelector("#nextBest"),
  stateSearch: document.querySelector("#stateSearch"),
  weekdayOnly: document.querySelector("#weekdayOnly"),
  primeOnly: document.querySelector("#primeOnly"),
  selectedName: document.querySelector("#selectedName"),
  selectedStatus: document.querySelector("#selectedStatus"),
  selectedTimes: document.querySelector("#selectedTimes"),
  stateRows: document.querySelector("#stateRows"),
  windowList: document.querySelector("#windowList"),
  refreshStamp: document.querySelector("#refreshStamp")
};

let selectedStateAbbr = "CO";

function zone(...values) {
  const zones = [];
  for (let index = 0; index < values.length; index += 2) {
    zones.push({ label: values[index], timeZone: values[index + 1] });
  }
  return zones;
}

function toMinutes(time) {
  const [hour, minute] = time.split(":").map(Number);
  return hour * 60 + minute;
}

function formatWindowTime(time) {
  const [hour, minute] = time.split(":").map(Number);
  return new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  }).format(new Date(2026, 0, 1, hour, minute));
}

function getZoneParts(date, timeZone) {
  const formatter = new Intl.DateTimeFormat("en-US", {
    timeZone,
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });

  const parts = Object.fromEntries(formatter.formatToParts(date).map((part) => [part.type, part.value]));
  const hour = Number(parts.hour) === 24 ? 0 : Number(parts.hour);

  return {
    weekday: parts.weekday,
    month: parts.month,
    day: parts.day,
    hour,
    minute: Number(parts.minute),
    second: Number(parts.second),
    minutes: hour * 60 + Number(parts.minute),
    label: `${parts.weekday}, ${parts.month} ${parts.day}`
  };
}

function formatZoneTime(date, timeZone) {
  return new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour: "numeric",
    minute: "2-digit",
    hour12: true
  }).format(date);
}

function isWeekday(parts) {
  return !["Sat", "Sun"].includes(parts.weekday);
}

function statusForZone(date, zoneInfo, settings) {
  const parts = getZoneParts(date, zoneInfo.timeZone);
  if (settings.weekdayOnly && !isWeekday(parts)) {
    return { state: "wait", label: "Weekend", tier: "wait", parts, window: null };
  }

  const eligibleWindows = CALL_WINDOWS.filter((window) => !settings.primeOnly || window.tier === "prime");
  const activeWindow = eligibleWindows.find((window) => {
    const start = toMinutes(window.start);
    const end = toMinutes(window.end);
    return parts.minutes >= start && parts.minutes < end;
  });

  if (!activeWindow) {
    return { state: "wait", label: "Wait", tier: "wait", parts, window: null };
  }

  return {
    state: "good",
    label: activeWindow.tier === "prime" ? "Prime now" : "Secondary now",
    tier: activeWindow.tier,
    parts,
    window: activeWindow
  };
}

function statusForState(date, state, settings) {
  const zoneStatuses = state.zones.map((zoneInfo) => ({
    ...zoneInfo,
    ...statusForZone(date, zoneInfo, settings),
    time: formatZoneTime(date, zoneInfo.timeZone)
  }));
  const prime = zoneStatuses.find((zoneStatus) => zoneStatus.state === "good" && zoneStatus.tier === "prime");
  const secondary = zoneStatuses.find((zoneStatus) => zoneStatus.state === "good");
  const active = prime || secondary;

  return {
    state: active ? "good" : "wait",
    tier: active ? active.tier : "wait",
    label: active ? active.label : "Wait",
    activeWindow: active ? active.window : null,
    zoneStatuses
  };
}

function nextWindowText(date, state, settings) {
  const zoneTexts = state.zones.map((zoneInfo) => {
    const parts = getZoneParts(date, zoneInfo.timeZone);
    const eligibleWindows = CALL_WINDOWS.filter((window) => !settings.primeOnly || window.tier === "prime");

    if (settings.weekdayOnly && !isWeekday(parts)) {
      return `${zoneInfo.label}: Monday ${formatWindowTime(eligibleWindows[0].start)}`;
    }

    const currentWindow = eligibleWindows.find((window) => {
      const start = toMinutes(window.start);
      const end = toMinutes(window.end);
      return parts.minutes >= start && parts.minutes < end;
    });

    if (currentWindow) {
      return `${zoneInfo.label}: now until ${formatWindowTime(currentWindow.end)}`;
    }

    const upcoming = eligibleWindows.find((window) => toMinutes(window.start) > parts.minutes);
    if (upcoming) {
      return `${zoneInfo.label}: ${formatWindowTime(upcoming.start)}`;
    }

    return `${zoneInfo.label}: tomorrow ${formatWindowTime(eligibleWindows[0].start)}`;
  });

  return zoneTexts.join(" | ");
}

function renderWindows() {
  dom.windowList.innerHTML = CALL_WINDOWS.map((window) => `
    <article class="window-card ${window.tier === "secondary" ? "secondary" : ""}">
      <strong>${window.label}</strong>
      <span>${formatWindowTime(window.start)}-${formatWindowTime(window.end)} local</span>
      <p>${window.why}</p>
    </article>
  `).join("");
}

function render() {
  const now = new Date();
  const settings = {
    weekdayOnly: dom.weekdayOnly.checked,
    primeOnly: dom.primeOnly.checked
  };
  const search = dom.stateSearch.value.trim().toLowerCase();
  const statesWithStatus = STATES.map((state) => ({
    ...state,
    status: statusForState(now, state, settings)
  }));
  const filteredStates = statesWithStatus.filter((state) => (
    state.name.toLowerCase().includes(search) || state.abbr.toLowerCase().includes(search)
  ));

  dom.userClock.textContent = new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  }).format(now);
  dom.userDate.textContent = new Intl.DateTimeFormat("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric"
  }).format(now);
  dom.refreshStamp.textContent = `Updated ${dom.userClock.textContent}`;

  const callableStates = statesWithStatus.filter((state) => state.status.state === "good");
  dom.callableCount.textContent = callableStates.length;
  dom.nextBest.textContent = callableStates.length ? callableStates[0].abbr : findNextBest(now, statesWithStatus, settings);

  renderRows(filteredStates, now, settings);
  renderSelected(now, settings);
}

function renderRows(states, now, settings) {
  const sorted = [...states].sort((a, b) => {
    const activeDelta = Number(b.status.state === "good") - Number(a.status.state === "good");
    return activeDelta || a.name.localeCompare(b.name);
  });

  dom.stateRows.innerHTML = sorted.map((state) => {
    const times = state.status.zoneStatuses.map((zoneStatus) => (
      `${zoneStatus.label}: ${zoneStatus.time}`
    )).join("<br>");
    const badgeClass = state.status.state === "good"
      ? state.status.tier === "secondary" ? "good secondary" : "good"
      : "";
    const rowClass = [
      state.status.state === "good" ? "good-row" : "",
      state.abbr === selectedStateAbbr ? "selected-row" : ""
    ].filter(Boolean).join(" ");
    return `
      <tr class="${rowClass}" data-state="${state.abbr}">
        <td><strong>${state.name}</strong><br><span class="muted">${state.abbr}</span></td>
        <td>${times}</td>
        <td><span class="status-badge ${badgeClass}">${state.status.label}</span></td>
        <td>${nextWindowText(now, state, settings)}</td>
      </tr>
    `;
  }).join("");
}

function renderSelected(now, settings) {
  const selected = STATES.find((state) => state.abbr === selectedStateAbbr) || STATES[0];
  const status = statusForState(now, selected, settings);
  dom.selectedName.textContent = `${selected.name} (${selected.abbr})`;
  dom.selectedStatus.textContent = status.state === "good"
    ? `${status.label}: ${status.activeWindow.label} until ${formatWindowTime(status.activeWindow.end)} local.`
    : `Not in a recommended window. ${nextWindowText(now, selected, settings)}`;
  dom.selectedTimes.innerHTML = status.zoneStatuses.map((zoneStatus) => `
    <div class="time-pill">
      <span>${zoneStatus.label}</span>
      <strong>${zoneStatus.time}</strong>
    </div>
  `).join("");
}

function findNextBest(now, states, settings) {
  const orderedZones = ["America/New_York", "America/Chicago", "America/Denver", "America/Los_Angeles", "America/Anchorage", "Pacific/Honolulu"];
  for (const zoneName of orderedZones) {
    const state = states.find((candidate) => candidate.zones.some((zoneInfo) => zoneInfo.timeZone === zoneName));
    if (!state) continue;
    const status = statusForState(now, state, settings);
    const nextText = nextWindowText(now, state, settings);
    if (status.state === "wait" && !nextText.includes("tomorrow")) {
      return state.abbr;
    }
  }
  return "--";
}

dom.stateRows.addEventListener("click", (event) => {
  const row = event.target.closest("[data-state]");
  if (!row) return;
  selectedStateAbbr = row.dataset.state;
  render();
});

[dom.stateSearch, dom.weekdayOnly, dom.primeOnly].forEach((control) => {
  control.addEventListener("input", render);
  control.addEventListener("change", render);
});

renderWindows();
render();
setInterval(render, 1000);
