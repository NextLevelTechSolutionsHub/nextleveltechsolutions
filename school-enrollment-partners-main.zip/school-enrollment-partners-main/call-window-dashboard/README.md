# Preschool Owner Call Windows

Static browser dashboard for tracking local call windows across all 50 states.

## Recommended Windows

- 9:15-10:30 AM local: after drop-off settles, before lunch transitions.
- 12:45-2:15 PM local: strongest window, aligned with nap or quiet time.
- 3:05-3:50 PM local: secondary gap after wake-up/snack and before pickup.
- 5:35-6:15 PM local: secondary owner/director catch-up window.

Open `index.html` directly in a browser, or run `start-preview.ps1` for a local `http://127.0.0.1:5177/` preview. The included `netlify.toml` publishes the folder root if you deploy it as a static site.
