# SEP Pricing Visualizer

Static multipage browser app for managing School Enrollment Partners customers, package pricing, hard costs, gross margins, bottlenecks, and upsells.

Open `index.html` directly in a browser, or run `start-preview.ps1` for a local preview at `http://127.0.0.1:5182/`.

## Customer Dashboard

Saved profiles marked as current customers appear in the dashboard. Sort them by churn risk, highest monthly payment, or alphabetical order. Churn risk is estimated from tenure, monthly revenue pressure, and performance score.

## App Pages

- Customers: book-of-business dashboard with sorting and risk scoring.
- Pricing Builder: profile editor, package selection, margin math, and recommended upsell.
- Upsells: add-on library with internal cost, profit, margin, labor, and cost explanations.
- Cost Model: editable HighLevel and labor assumptions.

## Memory

The app saves working data in browser local storage:

- current package
- current customer dashboard
- cost assumptions
- selected upsells
- prospect/client profiles
- notes and bottlenecks

Use the export button before clearing browser data or moving machines.
