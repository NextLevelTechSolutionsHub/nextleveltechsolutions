$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 5182
Set-Location $root
python -m http.server $port --bind 127.0.0.1
