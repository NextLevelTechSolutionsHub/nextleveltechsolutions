const STORAGE_KEY = "sepPricingVisualizer.v3";
const PREVIOUS_STORAGE_KEY = "sepPricingVisualizer.v2";
const LEGACY_STORAGE_KEY = "sepPricingVisualizer.v1";

const DEFAULT_ASSUMPTIONS = {
  highLevelPlanMonthly: 497,
  activeClientCount: 25,
  phoneNumberMonthly: 2,
  smsSegmentCost: 0.0083,
  emailCost: 0.000675,
  aiEmployeeGrowth: 50,
  aiEmployeeUnlimited: 97,
  onlineListings: 30,
  seoSearchAtlas: 79,
  premiumProspecting: 29,
  wordpressHosting: 10,
  workflowExecutionCost: 0.01,
  adManagerCost: 0,
  laborHourlyCost: 35
};

const TIERS = {
  inHome: {
    label: "In-home day care",
    packageName: "Warm Waitlist",
    price: 127,
    setup: 149,
    automation: 91,
    positioning: "A lightweight HighLevel sub-account for providers who need reviews, lead capture, missed-call backup, and waitlist follow-up without a big retainer.",
    included: [
      "HighLevel sub-account",
      "Review request workflow",
      "Parent inquiry form",
      "Missed-call text-back",
      "Basic waitlist follow-up",
      "Monthly snapshot"
    ],
    usage: {
      smsSegments: 120,
      emails: 250,
      workflowExecutions: 180,
      phoneNumbers: 1,
      hlAllocation: 1,
      laborHours: 0.15
    }
  },
  smallMedium: {
    label: "Small/medium center",
    packageName: "Enrollment Foundation",
    price: 349,
    setup: 349,
    automation: 88,
    positioning: "The main entry offer: use HighLevel to capture parent demand, trigger fast follow-up, improve trust, and create a clean enrollment pipeline.",
    included: [
      "HighLevel sub-account",
      "Google profile cleanup",
      "Review automation",
      "Parent lead form",
      "Missed-call text-back",
      "Follow-up sequence",
      "Basic pipeline",
      "Waitlist nurture"
    ],
    usage: {
      smsSegments: 420,
      emails: 900,
      workflowExecutions: 650,
      phoneNumbers: 1,
      hlAllocation: 1,
      laborHours: 0.25
    }
  },
  large: {
    label: "Large center / multi-site",
    packageName: "Enrollment Ops Base",
    price: 3500,
    setup: 2500,
    automation: 62,
    positioning: "A managed enrollment operations layer for operators with staff, classrooms, capacity pressure, and the ability to act on reporting.",
    included: [
      "HighLevel workspace",
      "Lead routing",
      "Pipeline by classroom",
      "Tour reminders",
      "Review workflow",
      "Performance reporting",
      "Monthly strategy review",
      "Bottleneck roadmap"
    ],
    usage: {
      smsSegments: 1800,
      emails: 3500,
      workflowExecutions: 2500,
      phoneNumbers: 3,
      hlAllocation: 2,
      onlineListings: 1,
      premiumProspecting: 1,
      laborHours: 10
    }
  }
};

const UPSELLS = [
  {
    id: "spotFill",
    name: "Spot Fill Sprint",
    price: 750,
    type: "one-time",
    fits: ["inHome", "smallMedium"],
    automation: "Medium",
    usage: { smsSegments: 350, emails: 650, workflowExecutions: 300, adManager: 1, laborHours: 2.25 },
    note: "A focused opening-fill push using existing HighLevel forms, workflows, and outbound follow-up. Client ad spend stays separate."
  },
  {
    id: "tourBooking",
    name: "Tour Booking System",
    price: 129,
    type: "monthly",
    fits: ["smallMedium", "large"],
    automation: "High",
    usage: { smsSegments: 120, emails: 180, workflowExecutions: 260, laborHours: 0.08 },
    note: "Adds calendars, confirmations, reminders, and reschedule nudges so parent inquiries convert into tours."
  },
  {
    id: "crmUpgrade",
    name: "CRM Pipeline Upgrade",
    price: 149,
    type: "monthly",
    fits: ["smallMedium"],
    automation: "High",
    usage: { workflowExecutions: 240, laborHours: 0.12 },
    note: "Adds enrollment stages, lead source tagging, simple tasks, and a director-friendly pipeline view."
  },
  {
    id: "mapGrid",
    name: "Local SEO Visibility",
    price: 249,
    type: "monthly",
    fits: ["smallMedium", "large"],
    automation: "High",
    usage: { seoSearchAtlas: 1, onlineListings: 1, emails: 60, laborHours: 0.25 },
    note: "Uses HighLevel SEO/Search Atlas and Online Listings so the client can see local visibility movement."
  },
  {
    id: "aiAssistant",
    name: "AI Parent Response Assistant",
    price: 249,
    type: "monthly",
    fits: ["smallMedium", "large"],
    automation: "Medium-high",
    usage: { aiEmployeeGrowth: 1, smsSegments: 700, emails: 250, workflowExecutions: 450, laborHours: 0.35 },
    note: "Uses AI Employee Growth for parent response support with human oversight and usage review."
  },
  {
    id: "aiUnlimited",
    name: "AI Employee Unlimited",
    price: 397,
    type: "monthly",
    fits: ["smallMedium", "large"],
    automation: "High",
    usage: { aiEmployeeUnlimited: 1, smsSegments: 900, emails: 300, workflowExecutions: 650, laborHours: 0.25 },
    note: "Upgrades the AI cost base to HighLevel AI Employee Unlimited for predictable heavier AI usage."
  },
  {
    id: "adsLite",
    name: "Paid Ads Management Lite",
    price: 497,
    type: "monthly",
    fits: ["smallMedium"],
    automation: "Medium",
    usage: { adManager: 1, smsSegments: 160, emails: 300, workflowExecutions: 300, laborHours: 1.1 },
    note: "Uses HighLevel Ad Manager at no platform cost. Client media spend is paid separately."
  },
  {
    id: "retargeting",
    name: "Retargeting Campaign",
    price: 249,
    type: "monthly",
    fits: ["smallMedium", "large"],
    automation: "Medium-high",
    usage: { adManager: 1, smsSegments: 100, emails: 220, workflowExecutions: 250, laborHours: 0.55 },
    note: "Re-engages warm parents from site traffic, forms, and old lead lists. Client ad spend stays separate."
  },
  {
    id: "noShow",
    name: "No-Show Recovery",
    price: 99,
    type: "monthly",
    fits: ["smallMedium", "large"],
    automation: "High",
    usage: { smsSegments: 220, emails: 220, workflowExecutions: 320, laborHours: 0.06 },
    note: "Automated tour no-show follow-up with reschedule prompts and director notifications."
  },
  {
    id: "responseCoaching",
    name: "Staff Response Coaching",
    price: 750,
    type: "one-time",
    fits: ["smallMedium", "large"],
    automation: "Low",
    usage: { emails: 30, laborHours: 5 },
    note: "Manual call review, response script cleanup, and staff coaching. Keep this scoped because labor drives cost."
  },
  {
    id: "capacityDashboard",
    name: "Capacity Dashboard",
    price: 497,
    type: "monthly",
    fits: ["large"],
    automation: "Medium",
    usage: { workflowExecutions: 650, emails: 180, premiumProspecting: 1, laborHours: 1.2 },
    note: "Shows openings, age groups, lead sources, and pipeline risk so campaigns match real capacity."
  },
  {
    id: "multiSite",
    name: "Multi-Site Reporting",
    price: 1000,
    type: "monthly",
    fits: ["large"],
    automation: "Medium",
    usage: { hlAllocation: 1, workflowExecutions: 1100, emails: 350, premiumProspecting: 1, laborHours: 2.2 },
    note: "Adds location-level reporting, cross-site comparison, and monthly operator review."
  },
  {
    id: "strategySprint",
    name: "Quarterly Strategy Sprint",
    price: 1500,
    type: "one-time",
    fits: ["large"],
    automation: "Low",
    usage: { emails: 80, workflowExecutions: 100, laborHours: 10 },
    note: "Manual premium strategy work: audit, findings, roadmap, and leadership recommendations."
  },
  {
    id: "wordpressLanding",
    name: "WordPress Landing Page",
    price: 199,
    type: "monthly",
    fits: ["smallMedium", "large"],
    automation: "Medium-high",
    usage: { wordpressHosting: 1, workflowExecutions: 120, laborHours: 0.3 },
    note: "Uses HighLevel WordPress hosting to keep a dedicated enrollment landing page live."
  }
];

const BOTTLENECKS = [
  { id: "missedCalls", label: "Missed calls / slow response", upsell: "aiAssistant", reason: "Fix response speed before buying more traffic. Parents usually move fast when shopping for care." },
  { id: "messyLeads", label: "Leads are disorganized", upsell: "crmUpgrade", reason: "A pipeline upgrade makes every inquiry visible and gives the director a next step." },
  { id: "notBookingTours", label: "Inquiries are not booking tours", upsell: "tourBooking", reason: "A tour booking system removes friction and gives interested parents a clear next action." },
  { id: "tourNoShows", label: "Tours are no-showing", upsell: "noShow", reason: "Recover demand you already generated before paying for more leads." },
  { id: "oneOpening", label: "One opening needs filled", upsell: "spotFill", reason: "A one-time sprint is cleaner than bloating the monthly package for one seat." },
  { id: "visibility", label: "Needs more local visibility", upsell: "mapGrid", reason: "HighLevel's SEO and Online Listings costs are real, so sell visibility at a price that leaves room for margin." },
  { id: "needsTraffic", label: "Can handle more leads now", upsell: "adsLite", reason: "Paid traffic makes sense after intake, follow-up, and booking are stable." },
  { id: "multiClassroom", label: "Multiple classrooms/locations", upsell: "capacityDashboard", reason: "Larger operators need demand matched to real capacity, not generic lead volume." }
];

const PAGES = {
  customers: {
    kicker: "Book of business",
    title: "Customers",
    summary: "Track current customers, payment level, performance, tenure, and churn risk."
  },
  builder: {
    kicker: "Pricing workspace",
    title: "Pricing Builder",
    summary: "Select a customer, tune the package, and see revenue, cost, margin, and the next best upsell."
  },
  upsells: {
    kicker: "Add-on library",
    title: "Upsells",
    summary: "Choose add-ons and inspect internal costs, profit, margin, labor, and why each cost exists."
  },
  costs: {
    kicker: "HighLevel assumptions",
    title: "Cost Model",
    summary: "Edit the HighLevel, message, AI, workflow, and labor assumptions that power every margin calculation."
  }
};

const dom = {
  pageKicker: document.querySelector("#pageKicker"),
  pageTitle: document.querySelector("#pageTitle"),
  pageSummary: document.querySelector("#pageSummary"),
  navItems: [...document.querySelectorAll("[data-page]")],
  pagePanels: [...document.querySelectorAll("[data-page-panel]")],
  memoryStatus: document.querySelector("#memoryStatus"),
  lastSaved: document.querySelector("#lastSaved"),
  customerSort: document.querySelector("#customerSort"),
  customerCount: document.querySelector("#customerCount"),
  customerRevenue: document.querySelector("#customerRevenue"),
  averageRisk: document.querySelector("#averageRisk"),
  highestRisk: document.querySelector("#highestRisk"),
  customerRows: document.querySelector("#customerRows"),
  newProfileBtn: document.querySelector("#newProfileBtn"),
  profileSelect: document.querySelector("#profileSelect"),
  clientName: document.querySelector("#clientName"),
  tierSelect: document.querySelector("#tierSelect"),
  bottleneckSelect: document.querySelector("#bottleneckSelect"),
  activeCustomerInput: document.querySelector("#activeCustomerInput"),
  openingsInput: document.querySelector("#openingsInput"),
  leadVolumeInput: document.querySelector("#leadVolumeInput"),
  startDateInput: document.querySelector("#startDateInput"),
  performanceInput: document.querySelector("#performanceInput"),
  notesInput: document.querySelector("#notesInput"),
  saveProfileBtn: document.querySelector("#saveProfileBtn"),
  deleteProfileBtn: document.querySelector("#deleteProfileBtn"),
  exportBtn: document.querySelector("#exportBtn"),
  importInput: document.querySelector("#importInput"),
  tierTabs: document.querySelector("#tierTabs"),
  packageName: document.querySelector("#packageName"),
  packagePositioning: document.querySelector("#packagePositioning"),
  includedList: document.querySelector("#includedList"),
  monthlyPrice: document.querySelector("#monthlyPrice"),
  setupPrice: document.querySelector("#setupPrice"),
  automationScore: document.querySelector("#automationScore"),
  monthlyRevenue: document.querySelector("#monthlyRevenue"),
  monthlyCost: document.querySelector("#monthlyCost"),
  grossProfit: document.querySelector("#grossProfit"),
  grossMargin: document.querySelector("#grossMargin"),
  activeUpsellCount: document.querySelector("#activeUpsellCount"),
  activeUpsellRevenue: document.querySelector("#activeUpsellRevenue"),
  activeUpsellCost: document.querySelector("#activeUpsellCost"),
  activeUpsellsList: document.querySelector("#activeUpsellsList"),
  upsellList: document.querySelector("#upsellList"),
  clearUpsellsBtn: document.querySelector("#clearUpsellsBtn"),
  recommendedTitle: document.querySelector("#recommendedTitle"),
  recommendedReason: document.querySelector("#recommendedReason"),
  recommendedRevenue: document.querySelector("#recommendedRevenue"),
  recommendedCost: document.querySelector("#recommendedCost"),
  addRecommendedBtn: document.querySelector("#addRecommendedBtn"),
  highLevelPlanInput: document.querySelector("#highLevelPlanInput"),
  activeClientsInput: document.querySelector("#activeClientsInput"),
  phoneNumberInput: document.querySelector("#phoneNumberInput"),
  smsCostInput: document.querySelector("#smsCostInput"),
  emailCostInput: document.querySelector("#emailCostInput"),
  aiGrowthInput: document.querySelector("#aiGrowthInput"),
  aiUnlimitedInput: document.querySelector("#aiUnlimitedInput"),
  onlineListingsInput: document.querySelector("#onlineListingsInput"),
  seoInput: document.querySelector("#seoInput"),
  workflowInput: document.querySelector("#workflowInput"),
  laborCostInput: document.querySelector("#laborCostInput"),
  resetAssumptionsBtn: document.querySelector("#resetAssumptionsBtn")
};

let state = loadState();

function todayString() {
  return new Date().toISOString().slice(0, 10);
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function defaultProfile() {
  return {
    id: crypto.randomUUID(),
    name: "",
    tier: "smallMedium",
    bottleneck: "missedCalls",
    activeCustomer: true,
    startDate: todayString(),
    performanceScore: 70,
    openings: 2,
    leadVolume: 20,
    notes: "",
    selectedUpsells: []
  };
}

function loadState() {
  const fallback = {
    assumptions: { ...DEFAULT_ASSUMPTIONS },
    activeProfileId: null,
    customerSort: "churnRisk",
    activePage: "customers",
    profiles: []
  };

  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || localStorage.getItem(PREVIOUS_STORAGE_KEY) || localStorage.getItem(LEGACY_STORAGE_KEY));
    if (!saved) return fallback;
    return {
      assumptions: { ...DEFAULT_ASSUMPTIONS, ...saved.assumptions },
      activeProfileId: saved.activeProfileId || null,
      customerSort: saved.customerSort || "churnRisk",
      activePage: saved.activePage || "customers",
      profiles: Array.isArray(saved.profiles) ? saved.profiles.map(normalizeProfile) : []
    };
  } catch {
    return fallback;
  }
}

function normalizeProfile(profile) {
  return {
    ...defaultProfile(),
    ...profile,
    activeCustomer: profile.activeCustomer !== false,
    startDate: profile.startDate || todayString(),
    performanceScore: clamp(Number(profile.performanceScore ?? 70), 0, 100),
    tier: TIERS[profile.tier] ? profile.tier : "smallMedium",
    bottleneck: BOTTLENECKS.some((item) => item.id === profile.bottleneck) ? profile.bottleneck : "missedCalls",
    selectedUpsells: Array.isArray(profile.selectedUpsells) ? profile.selectedUpsells.filter((id) => UPSELLS.some((upsell) => upsell.id === id)) : []
  };
}

function activeProfile() {
  let profile = state.profiles.find((item) => item.id === state.activeProfileId);
  if (!profile) {
    profile = defaultProfile();
    state.profiles.unshift(profile);
    state.activeProfileId = profile.id;
  }
  return profile;
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  const stamp = new Intl.DateTimeFormat("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit"
  }).format(new Date());
  dom.lastSaved.textContent = `Saved ${stamp}`;
  dom.memoryStatus.textContent = "Saved locally";
}

function setActivePage(page) {
  const nextPage = PAGES[page] ? page : "customers";
  state.activePage = nextPage;
  const meta = PAGES[nextPage];
  dom.pageKicker.textContent = meta.kicker;
  dom.pageTitle.textContent = meta.title;
  dom.pageSummary.textContent = meta.summary;
  dom.navItems.forEach((item) => item.classList.toggle("active", item.dataset.page === nextPage));
  dom.pagePanels.forEach((panel) => panel.classList.toggle("active", panel.dataset.pagePanel === nextPage));
}

function money(value, digits = 0) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  }).format(value);
}

function percent(value) {
  if (!Number.isFinite(value)) return "0%";
  return `${Math.round(value)}%`;
}

function highLevelAllocation() {
  const clientCount = Math.max(1, state.assumptions.activeClientCount || 1);
  return state.assumptions.highLevelPlanMonthly / clientCount;
}

function costBreakdown(usage = {}, contextLabel = "this automation") {
  const a = state.assumptions;
  const rows = [];
  const push = (label, amount, detail) => {
    if (amount > 0) rows.push({ label, amount, detail });
  };

  push(
    "HighLevel plan allocation",
    (usage.hlAllocation || 0) * highLevelAllocation(),
    `${usage.hlAllocation || 0} allocation unit(s) x ${money(highLevelAllocation(), 2)} based on ${a.activeClientCount} active clients sharing the ${money(a.highLevelPlanMonthly)} agency plan.`
  );
  push(
    "LC Phone numbers",
    (usage.phoneNumbers || 0) * a.phoneNumberMonthly,
    `${usage.phoneNumbers || 0} number(s) x ${money(a.phoneNumberMonthly, 2)} for call tracking, missed-call text-back, and local routing.`
  );
  push(
    "LC SMS segments",
    (usage.smsSegments || 0) * a.smsSegmentCost,
    `${usage.smsSegments || 0} segment(s) x ${money(a.smsSegmentCost, 4)}. For ${contextLabel}, this estimates confirmation, reminder, follow-up, and recovery texts.`
  );
  push(
    "LC Email sends",
    (usage.emails || 0) * a.emailCost,
    `${usage.emails || 0} send(s) x ${money(a.emailCost, 4)} for nurture, confirmations, reminders, and monthly parent follow-up.`
  );
  push(
    "AI Employee Growth",
    (usage.aiEmployeeGrowth || 0) * a.aiEmployeeGrowth,
    `${usage.aiEmployeeGrowth || 0} sub-account license x ${money(a.aiEmployeeGrowth)} for HighLevel AI Employee Growth.`
  );
  push(
    "AI Employee Unlimited",
    (usage.aiEmployeeUnlimited || 0) * a.aiEmployeeUnlimited,
    `${usage.aiEmployeeUnlimited || 0} sub-account license x ${money(a.aiEmployeeUnlimited)} for predictable heavier AI usage.`
  );
  push(
    "Online Listings",
    (usage.onlineListings || 0) * a.onlineListings,
    `${usage.onlineListings || 0} listing add-on x ${money(a.onlineListings)} for directory presence and local trust signals.`
  );
  push(
    "SEO / Search Atlas",
    (usage.seoSearchAtlas || 0) * a.seoSearchAtlas,
    `${usage.seoSearchAtlas || 0} SEO add-on x ${money(a.seoSearchAtlas)} for visibility tracking and local SEO work.`
  );
  push(
    "Premium Prospecting",
    (usage.premiumProspecting || 0) * a.premiumProspecting,
    `${usage.premiumProspecting || 0} premium data/reporting unit x ${money(a.premiumProspecting)}.`
  );
  push(
    "WordPress hosting",
    (usage.wordpressHosting || 0) * a.wordpressHosting,
    `${usage.wordpressHosting || 0} hosted site x ${money(a.wordpressHosting)} for a dedicated enrollment page.`
  );
  push(
    "Workflow executions",
    (usage.workflowExecutions || 0) * a.workflowExecutionCost,
    `${usage.workflowExecutions || 0} execution(s) x ${money(a.workflowExecutionCost, 3)} for automations, triggers, reminders, and task creation.`
  );
  push(
    "HighLevel Ad Manager",
    (usage.adManager || 0) * a.adManagerCost,
    `${usage.adManager || 0} ad manager unit(s). Platform cost is set to ${money(a.adManagerCost)}; client media spend is separate.`
  );
  push(
    "Manual labor",
    (usage.laborHours || 0) * a.laborHourlyCost,
    `${(usage.laborHours || 0).toFixed(2)} hour(s) x ${money(a.laborHourlyCost)} for setup, review, tuning, or reporting.`
  );

  return rows;
}

function usageCost(usage) {
  return costBreakdown(usage).reduce((total, row) => total + row.amount, 0);
}

function recurringPrice(item) {
  return item.type === "monthly" ? item.price : 0;
}

function recurringCost(item) {
  return item.type === "monthly" ? usageCost(item.usage) : 0;
}

function itemFinancials(item) {
  const cost = usageCost(item.usage);
  const profit = item.price - cost;
  const margin = item.price > 0 ? (profit / item.price) * 100 : 0;
  return { cost, profit, margin };
}

function initStaticControls() {
  dom.tierSelect.innerHTML = Object.entries(TIERS)
    .map(([id, tier]) => `<option value="${id}">${tier.label}</option>`)
    .join("");

  dom.bottleneckSelect.innerHTML = BOTTLENECKS
    .map((item) => `<option value="${item.id}">${item.label}</option>`)
    .join("");

  dom.tierTabs.innerHTML = Object.entries(TIERS)
    .map(([id, tier]) => `<button class="tier-tab" type="button" data-tier="${id}">${tier.label}</button>`)
    .join("");
}

function syncInputsFromProfile() {
  const profile = activeProfile();
  dom.customerSort.value = state.customerSort || "churnRisk";
  dom.clientName.value = profile.name;
  dom.tierSelect.value = profile.tier;
  dom.bottleneckSelect.value = profile.bottleneck;
  dom.activeCustomerInput.checked = profile.activeCustomer !== false;
  dom.openingsInput.value = profile.openings;
  dom.leadVolumeInput.value = profile.leadVolume;
  dom.startDateInput.value = profile.startDate || todayString();
  dom.performanceInput.value = profile.performanceScore ?? 70;
  dom.notesInput.value = profile.notes;

  dom.highLevelPlanInput.value = state.assumptions.highLevelPlanMonthly;
  dom.activeClientsInput.value = state.assumptions.activeClientCount;
  dom.phoneNumberInput.value = state.assumptions.phoneNumberMonthly;
  dom.smsCostInput.value = state.assumptions.smsSegmentCost;
  dom.emailCostInput.value = state.assumptions.emailCost;
  dom.aiGrowthInput.value = state.assumptions.aiEmployeeGrowth;
  dom.aiUnlimitedInput.value = state.assumptions.aiEmployeeUnlimited;
  dom.onlineListingsInput.value = state.assumptions.onlineListings;
  dom.seoInput.value = state.assumptions.seoSearchAtlas;
  dom.workflowInput.value = state.assumptions.workflowExecutionCost;
  dom.laborCostInput.value = state.assumptions.laborHourlyCost;
}

function renderProfileSelect() {
  dom.profileSelect.innerHTML = state.profiles.map((profile) => {
    const tier = TIERS[profile.tier]?.label || "Profile";
    const name = profile.name.trim() || "Unsaved prospect";
    return `<option value="${profile.id}">${name} - ${tier}</option>`;
  }).join("");
  dom.profileSelect.value = state.activeProfileId;
}

function monthlyRevenueForProfile(profile) {
  const tier = TIERS[profile.tier] || TIERS.smallMedium;
  const recurringUpsells = UPSELLS.filter((upsell) => (
    profile.selectedUpsells.includes(upsell.id) && upsell.type === "monthly"
  ));
  return tier.price + recurringUpsells.reduce((total, upsell) => total + upsell.price, 0);
}

function tenureMonths(profile) {
  const start = new Date(`${profile.startDate || todayString()}T00:00:00`);
  if (Number.isNaN(start.getTime())) return 0;
  const now = new Date();
  const months = (now.getFullYear() - start.getFullYear()) * 12 + now.getMonth() - start.getMonth();
  return Math.max(0, months);
}

function churnRisk(profile) {
  const performance = clamp(Number(profile.performanceScore ?? 70), 0, 100);
  const months = tenureMonths(profile);
  const revenue = monthlyRevenueForProfile(profile);
  const performanceRisk = (100 - performance) * 0.58;
  const tenureRisk = months < 3 ? 28 : months < 6 ? 20 : months < 12 ? 12 : months < 24 ? 6 : 2;
  const pricePressure = revenue >= 1500 ? 14 : revenue >= 750 ? 10 : revenue >= 350 ? 6 : 3;
  return clamp(Math.round(performanceRisk + tenureRisk + pricePressure), 0, 100);
}

function riskLabel(score) {
  if (score >= 70) return "High";
  if (score >= 45) return "Watch";
  return "Stable";
}

function riskReason(profile) {
  const months = tenureMonths(profile);
  const performance = clamp(Number(profile.performanceScore ?? 70), 0, 100);
  const revenue = monthlyRevenueForProfile(profile);
  const reasons = [];
  if (performance < 55) reasons.push("low performance score");
  if (months < 6) reasons.push("newer account");
  if (revenue >= 750) reasons.push("higher invoice pressure");
  if (!reasons.length) reasons.push("solid tenure and results");
  return reasons.join(", ");
}

function renderCustomerDashboard() {
  const activeCustomers = state.profiles.filter((profile) => profile.activeCustomer !== false);
  const sorted = [...activeCustomers].sort((a, b) => {
    if (state.customerSort === "alphabetical") {
      return (a.name || "").localeCompare(b.name || "");
    }
    if (state.customerSort === "highestPaying") {
      return monthlyRevenueForProfile(b) - monthlyRevenueForProfile(a);
    }
    return churnRisk(b) - churnRisk(a);
  });
  const totalRevenue = activeCustomers.reduce((total, profile) => total + monthlyRevenueForProfile(profile), 0);
  const averageRisk = activeCustomers.length
    ? activeCustomers.reduce((total, profile) => total + churnRisk(profile), 0) / activeCustomers.length
    : 0;
  const highest = [...activeCustomers].sort((a, b) => churnRisk(b) - churnRisk(a))[0];

  dom.customerCount.textContent = activeCustomers.length;
  dom.customerRevenue.textContent = money(totalRevenue);
  dom.averageRisk.textContent = percent(averageRisk);
  dom.highestRisk.textContent = highest ? `${highest.name || "Unnamed"} (${churnRisk(highest)}%)` : "None";

  if (!sorted.length) {
    dom.customerRows.innerHTML = `<p class="empty-state">No current customers yet. Mark a saved profile as current to see it here.</p>`;
    return;
  }

  dom.customerRows.innerHTML = sorted.map((profile) => {
    const risk = churnRisk(profile);
    const tier = TIERS[profile.tier] || TIERS.smallMedium;
    const name = profile.name.trim() || "Unnamed customer";
    const selected = profile.id === state.activeProfileId ? "selected" : "";
    return `
      <button type="button" class="customer-row ${selected}" data-profile-id="${profile.id}">
        <span>
          <strong>${name}</strong>
          <em>${tier.label} - ${tenureMonths(profile)} mo - ${profile.performanceScore ?? 70}% performance</em>
        </span>
        <span>${money(monthlyRevenueForProfile(profile))}/mo</span>
        <span class="risk-badge ${risk >= 70 ? "risk-high" : risk >= 45 ? "risk-watch" : "risk-stable"}">${riskLabel(risk)} ${risk}%</span>
        <small>${riskReason(profile)}</small>
      </button>
    `;
  }).join("");
}

function renderPackage() {
  const profile = activeProfile();
  const tier = TIERS[profile.tier];
  const selectedUpsells = UPSELLS.filter((upsell) => profile.selectedUpsells.includes(upsell.id));
  const recurringUpsells = selectedUpsells.filter((upsell) => upsell.type === "monthly");
  const monthlyRevenue = tier.price + recurringUpsells.reduce((total, upsell) => total + recurringPrice(upsell), 0);
  const monthlyCost = usageCost(tier.usage) + recurringUpsells.reduce((total, upsell) => total + recurringCost(upsell), 0);
  const profit = monthlyRevenue - monthlyCost;
  const margin = monthlyRevenue > 0 ? (profit / monthlyRevenue) * 100 : 0;

  dom.packageName.textContent = tier.packageName;
  dom.packagePositioning.textContent = tier.positioning;
  dom.includedList.innerHTML = tier.included.map((item) => `<span>${item}</span>`).join("");
  dom.monthlyPrice.textContent = money(tier.price);
  dom.setupPrice.textContent = money(tier.setup);
  dom.automationScore.textContent = percent(tier.automation);
  dom.monthlyRevenue.textContent = money(monthlyRevenue);
  dom.monthlyCost.textContent = money(monthlyCost);
  dom.grossProfit.textContent = money(profit);
  dom.grossMargin.textContent = percent(margin);
  dom.grossMargin.className = margin >= 75 ? "good" : margin >= 60 ? "warn" : "risk";

  [...dom.tierTabs.querySelectorAll(".tier-tab")].forEach((button) => {
    button.classList.toggle("active", button.dataset.tier === profile.tier);
  });
}

function renderActiveUpsells() {
  const profile = activeProfile();
  const selectedUpsells = UPSELLS.filter((upsell) => profile.selectedUpsells.includes(upsell.id));
  const recurring = selectedUpsells.filter((upsell) => upsell.type === "monthly");
  const recurringRevenue = recurring.reduce((total, upsell) => total + upsell.price, 0);
  const recurringCostTotal = recurring.reduce((total, upsell) => total + usageCost(upsell.usage), 0);

  dom.activeUpsellCount.textContent = selectedUpsells.length;
  dom.activeUpsellRevenue.textContent = money(recurringRevenue);
  dom.activeUpsellCost.textContent = money(recurringCostTotal);

  if (!selectedUpsells.length) {
    dom.activeUpsellsList.innerHTML = `<p class="empty-state">Select add-ons below and they will appear here.</p>`;
    return;
  }

  dom.activeUpsellsList.innerHTML = selectedUpsells.map((upsell) => {
    const financials = itemFinancials(upsell);
    const priceLabel = upsell.type === "monthly" ? `${money(upsell.price)}/mo` : `${money(upsell.price)} once`;
    return `
      <article class="active-upsell-card">
        <div>
          <strong>${upsell.name}</strong>
          <span>${priceLabel} - ${percent(financials.margin)} margin - ${(upsell.usage.laborHours || 0).toFixed(2)} labor hrs</span>
        </div>
        <button type="button" class="remove-upsell" data-remove-upsell="${upsell.id}" aria-label="Remove ${upsell.name}">Remove</button>
      </article>
    `;
  }).join("");
}

function renderUpsells() {
  const profile = activeProfile();
  const fitUpsells = UPSELLS.filter((upsell) => upsell.fits.includes(profile.tier));
  dom.upsellList.innerHTML = fitUpsells.map((upsell) => {
    const selected = profile.selectedUpsells.includes(upsell.id);
    const financials = itemFinancials(upsell);
    const priceLabel = upsell.type === "monthly" ? `${money(upsell.price)}/mo` : `${money(upsell.price)} once`;
    const costLabel = upsell.type === "monthly" ? `${money(financials.cost)}/mo` : `${money(financials.cost)} one-time`;
    const profitLabel = upsell.type === "monthly" ? `${money(financials.profit)}/mo` : `${money(financials.profit)} one-time`;
    const breakdown = costBreakdown(upsell.usage, upsell.name)
      .map((row) => `
        <span>
          <b>${row.label}: ${money(row.amount, row.amount < 1 ? 2 : 0)}</b>
          ${row.detail}
        </span>
      `)
      .join("");

    return `
      <article class="upsell-item ${selected ? "selected" : ""}">
        <div class="upsell-main">
          <label class="upsell-check">
            <input type="checkbox" data-upsell="${upsell.id}" ${selected ? "checked" : ""}>
            <span>
              <strong>${upsell.name}</strong>
              <em>${priceLabel} - Automation: ${upsell.automation}</em>
            </span>
          </label>
          <p>${upsell.note}</p>
        </div>
        <div class="upsell-financials">
          <span><b>${costLabel}</b> internal cost</span>
          <span><b>${profitLabel}</b> gross profit</span>
          <span><b>${percent(financials.margin)}</b> margin</span>
          <span><b>${(upsell.usage.laborHours || 0).toFixed(2)} hrs</b> manual labor</span>
        </div>
        <div class="cost-breakdown">${breakdown || "<span>No meaningful direct platform cost.</span>"}</div>
      </article>
    `;
  }).join("");
}

function renderRecommendation() {
  const profile = activeProfile();
  const bottleneck = BOTTLENECKS.find((item) => item.id === profile.bottleneck) || BOTTLENECKS[0];
  let upsell = UPSELLS.find((item) => item.id === bottleneck.upsell && item.fits.includes(profile.tier));

  if (!upsell) {
    upsell = UPSELLS.find((item) => item.fits.includes(profile.tier));
  }

  if (!upsell) {
    dom.recommendedTitle.textContent = "No upsell fit";
    dom.recommendedReason.textContent = "This tier does not have a matching add-on yet.";
    dom.recommendedRevenue.textContent = "$0";
    dom.recommendedCost.textContent = "$0";
    dom.addRecommendedBtn.disabled = true;
    return;
  }

  const financials = itemFinancials(upsell);
  dom.recommendedTitle.textContent = upsell.name;
  dom.recommendedReason.textContent = bottleneck.reason;
  dom.recommendedRevenue.textContent = upsell.type === "monthly" ? `${money(upsell.price)}/mo` : `${money(upsell.price)} once`;
  dom.recommendedCost.textContent = upsell.type === "monthly" ? `${money(financials.cost)}/mo` : `${money(financials.cost)} once`;
  dom.addRecommendedBtn.disabled = profile.selectedUpsells.includes(upsell.id);
  dom.addRecommendedBtn.dataset.upsell = upsell.id;
}

function render() {
  setActivePage(state.activePage);
  renderProfileSelect();
  syncInputsFromProfile();
  renderCustomerDashboard();
  renderPackage();
  renderActiveUpsells();
  renderUpsells();
  renderRecommendation();
}

function updateActiveProfile(patch) {
  const profile = activeProfile();
  Object.assign(profile, patch);
  saveState();
  render();
}

function removeUpsell(upsellId) {
  const profile = activeProfile();
  updateActiveProfile({ selectedUpsells: profile.selectedUpsells.filter((id) => id !== upsellId) });
}

function bindEvents() {
  dom.navItems.forEach((item) => {
    item.addEventListener("click", () => {
      state.activePage = item.dataset.page;
      saveState();
      setActivePage(state.activePage);
    });
  });

  dom.newProfileBtn.addEventListener("click", () => {
    const profile = defaultProfile();
    state.profiles.unshift(profile);
    state.activeProfileId = profile.id;
    state.activePage = "builder";
    saveState();
    render();
  });

  dom.profileSelect.addEventListener("change", () => {
    state.activeProfileId = dom.profileSelect.value;
    saveState();
    render();
  });

  dom.clientName.addEventListener("input", () => updateActiveProfile({ name: dom.clientName.value }));
  dom.tierSelect.addEventListener("change", () => updateActiveProfile({ tier: dom.tierSelect.value, selectedUpsells: [] }));
  dom.bottleneckSelect.addEventListener("change", () => updateActiveProfile({ bottleneck: dom.bottleneckSelect.value }));
  dom.activeCustomerInput.addEventListener("change", () => updateActiveProfile({ activeCustomer: dom.activeCustomerInput.checked }));
  dom.openingsInput.addEventListener("input", () => updateActiveProfile({ openings: Number(dom.openingsInput.value) || 0 }));
  dom.leadVolumeInput.addEventListener("input", () => updateActiveProfile({ leadVolume: Number(dom.leadVolumeInput.value) || 0 }));
  dom.startDateInput.addEventListener("input", () => updateActiveProfile({ startDate: dom.startDateInput.value || todayString() }));
  dom.performanceInput.addEventListener("input", () => updateActiveProfile({ performanceScore: clamp(Number(dom.performanceInput.value) || 0, 0, 100) }));
  dom.notesInput.addEventListener("input", () => updateActiveProfile({ notes: dom.notesInput.value }));

  dom.customerSort.addEventListener("change", () => {
    state.customerSort = dom.customerSort.value;
    saveState();
    renderCustomerDashboard();
  });

  dom.customerRows.addEventListener("click", (event) => {
    const row = event.target.closest("[data-profile-id]");
    if (!row) return;
    state.activeProfileId = row.dataset.profileId;
    state.activePage = "builder";
    saveState();
    render();
  });

  dom.tierTabs.addEventListener("click", (event) => {
    const button = event.target.closest("[data-tier]");
    if (!button) return;
    updateActiveProfile({ tier: button.dataset.tier, selectedUpsells: [] });
  });

  dom.upsellList.addEventListener("change", (event) => {
    const input = event.target.closest("[data-upsell]");
    if (!input) return;
    const profile = activeProfile();
    const selected = new Set(profile.selectedUpsells);
    if (input.checked) {
      selected.add(input.dataset.upsell);
    } else {
      selected.delete(input.dataset.upsell);
    }
    updateActiveProfile({ selectedUpsells: [...selected] });
  });

  dom.activeUpsellsList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-remove-upsell]");
    if (!button) return;
    removeUpsell(button.dataset.removeUpsell);
  });

  dom.clearUpsellsBtn.addEventListener("click", () => updateActiveProfile({ selectedUpsells: [] }));

  dom.addRecommendedBtn.addEventListener("click", () => {
    const upsellId = dom.addRecommendedBtn.dataset.upsell;
    if (!upsellId) return;
    const profile = activeProfile();
    updateActiveProfile({ selectedUpsells: [...new Set([...profile.selectedUpsells, upsellId])] });
  });

  dom.saveProfileBtn.addEventListener("click", () => {
    saveState();
    render();
  });

  dom.deleteProfileBtn.addEventListener("click", () => {
    const profile = activeProfile();
    state.profiles = state.profiles.filter((item) => item.id !== profile.id);
    state.activeProfileId = state.profiles[0]?.id || null;
    saveState();
    render();
  });

  dom.exportBtn.addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "sep-pricing-visualizer-export.json";
    link.click();
    URL.revokeObjectURL(url);
  });

  dom.importInput.addEventListener("change", async () => {
    const file = dom.importInput.files[0];
    if (!file) return;
    const text = await file.text();
    const imported = JSON.parse(text);
    state = {
      assumptions: { ...DEFAULT_ASSUMPTIONS, ...imported.assumptions },
      activeProfileId: imported.activeProfileId || null,
      customerSort: imported.customerSort || "churnRisk",
      activePage: imported.activePage || "customers",
      profiles: Array.isArray(imported.profiles) ? imported.profiles.map(normalizeProfile) : []
    };
    saveState();
    render();
    dom.importInput.value = "";
  });

  [
    ["highLevelPlanMonthly", dom.highLevelPlanInput],
    ["activeClientCount", dom.activeClientsInput],
    ["phoneNumberMonthly", dom.phoneNumberInput],
    ["smsSegmentCost", dom.smsCostInput],
    ["emailCost", dom.emailCostInput],
    ["aiEmployeeGrowth", dom.aiGrowthInput],
    ["aiEmployeeUnlimited", dom.aiUnlimitedInput],
    ["onlineListings", dom.onlineListingsInput],
    ["seoSearchAtlas", dom.seoInput],
    ["workflowExecutionCost", dom.workflowInput],
    ["laborHourlyCost", dom.laborCostInput]
  ].forEach(([key, input]) => {
    input.addEventListener("input", () => {
      state.assumptions[key] = Number(input.value) || 0;
      saveState();
      renderPackage();
      renderActiveUpsells();
      renderUpsells();
      renderRecommendation();
    });
  });

  dom.resetAssumptionsBtn.addEventListener("click", () => {
    state.assumptions = { ...DEFAULT_ASSUMPTIONS };
    saveState();
    render();
  });
}

initStaticControls();
activeProfile();
bindEvents();
saveState();
render();
